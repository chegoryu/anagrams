# The `dev` folder

This folder is for development and testing purposes and can be safely removed.

Use this folder to place any development files for your own local application / testing.

Any files placed here (except the `about/README.md` and files placed in `dev/maybe`) will be ignored by `git`.

This also helps with CMake support, making it easy to exclude development files from the `CMakeLists.txt` file.
